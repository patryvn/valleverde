# Valle Verde 0.3.0 — proyecto Android

Incluye un prototipo jugable offline con:
- Mapa isométrico pequeño, ampliable mediante construcción.
- Tres aldeanos iniciales, asignación de oficios y prioridades.
- Contratación permanente y jornaleros.
- Cultivos, estaciones, clima y velocidad ajustable.
- Gallinas, vacas y cabras; establos/gallineros y reproducción simulada.
- Mercado, fabricación, pesca, caza, bosque, cantera, misiones y decoración.
- Habitantes y animales representados sobre el mapa; los trabajadores se desplazan visualmente.
- Guardado local automático en el dispositivo.

## Jugar ahora sin instalar APK
Abre `app/src/main/assets/index.html` en Chrome en Android. Es una versión web local y funciona sin conexión una vez descargada. Según el navegador, puede ser necesario elegir Chrome en «Abrir con».

## Obtener el APK usando solo el móvil
Este proyecto incluye `.github/workflows/build-apk.yml` para compilar en GitHub Actions:
1. Crea un repositorio nuevo en https://github.com desde el móvil.
2. Extrae el ZIP y sube el contenido de la carpeta `ValleVerde` a la raíz del repositorio, incluida la carpeta oculta `.github`.
3. Abre la pestaña Actions y ejecuta **Build Valle Verde APK** (o espera a que termine el flujo).
4. En la ejecución completada, descarga el artefacto `ValleVerde-debug-apk`.
5. Extrae `app-debug.apk` e instálalo. Android puede pedir permiso para instalar desde esa fuente.

**Importante:** este paquete contiene el código fuente y el flujo de compilación, no un APK ya compilado. No se ha podido compilar aquí porque este entorno no tiene Android SDK/Gradle instalado. La versión 0.3.0 es un prototipo: varios sistemas (familias, pesca/caza, reproducción y economía) son simulaciones sencillas y no una simulación profunda todavía.
