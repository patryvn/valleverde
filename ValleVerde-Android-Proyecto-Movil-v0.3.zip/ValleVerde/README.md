# Valle Verde Android — versión 0.2.0
Juego offline de gestión de aldea con mapa isométrico, agricultura, oficios, contratación, ganadería, estaciones, economía y supervivencia equilibrada.

Para compilar: usa Android Studio o el flujo GitHub Actions descrito en README-MOVIL.md. El APK de depuración se publica como artefacto `ValleVerde-debug-apk`.
